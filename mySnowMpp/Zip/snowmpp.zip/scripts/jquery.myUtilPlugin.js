;$.myBtnLuClass='.btnLu';
;$.myBtnCalClass='.btnCal';
;$.myBtnCalAcceptId='#divBtnCalAccept';
;$.myBtnCalRejectId='#divBtnCalReject';
;$.myBtnDpExitId='#divBtnDpExit';
;$.myBtnDpTimeUpdId='#divBtnDpTimeUpd';
;$.myBtnDpEmtpyId='#divBtnDpEmpty';
;$.myInpTimeId='#inpTime';
;$.myBtnLuExitId='#divBtnLuExit';
;$.myBtnLuSelectClass='.trBtnLuSelect';
;$.myBtn3GlyphClass='.btn3Glyph';
;$.myBtn3luGlyphClass='.btn3luGlyph';
;$.myBtn3lurGlyphClass='.btn3lurGlyph';
;$.myBtn3SortGlyphClass='.btn3SortGlyph';
;$.myTbLuId='#tblLu';
;$.myDivDatePickerContainerId='#divDatePickerContainer';
;$.myDivLuContainerId='#divLuContainer';
;(function ($, window, document, undefined) {
	// *******************************************
	// Augment prototypes
	if (!Array.prototype.last){
		Array.prototype.last = function(){
			return this[this.length - 1];
		};
	};
	if (!Array.prototype.updLast){
		Array.prototype.updLast = function(value){
			this[this.length - 1]=value;
			return this[this.length - 1];			
		};
	};		
	if (!Array.prototype.updLastProp){
		Array.prototype.updLastProp = function(value,p){
			this[this.length - 1][p]=value;
			return this[this.length - 1][p];
		};
	};	
	if (!Array.prototype.first){
		Array.prototype.first = function(value){
			this[0] = value;
			return this[0];
		};
	};	
	if (!Array.prototype.updFirst){
		Array.prototype.updFirst = function(){
			return this[0];
		};
	};
	if (!Array.prototype.updFirstProp){
		Array.prototype.updFirstProp = function(value,p){
			this[0][p]=value;
			return this[0][p];
		};
	};	
	
	// *******************************************
	// BEGIN Private variables  
	// -------------------------------------------
	var _eFieldParent;
	var _eFieldDiv;
	var _eDtmDiv;
	var _pDummy = [{label:"none",value:"none"}]; 
    var _p;
	var _cLuBuildStr =
			'<tr><th>Select <%=s%></th></tr>'+
			'<% for (var i=0,iL=p.length;i<iL;i++) {%>'+
			'<tr class="trBtnLuSelect">' +
			'<td value="<%=p[i].value%>">' +
			'<%=p[i].label%></td></tr><%}%>';
	var _cLuCiBuildStr = 
			'<tr><th colspan="3" style="border-bottom:none;">Select <%=s%></th></tr>'+
			'<tr><th colspan="2" style="display:table-cell;<%if (isSearch){%>border-bottom:none;<%}%>"><input id="inpTextSearch" type="text" value="" style="color:black;"/></th>'+
		    '<th style="display:table-cell;<%if (isSearch){%>border-bottom:none;<%}%>"><div class="btn3luGlyph" style="font-size:12px;width=100%;text-align:center;"><span class="glyphicon glyphicon-search" style="vertical-align:middle;"></span></div>'+
		    '<%if (isSearch){%><div class="btn3lurGlyph" style="font-size:15px;width=100%;text-align:center;padding-left:8px;"><span class="glyphicon glyphicon-remove" style="vertical-align:bottom;"></span></div><%}%></th></tr>'+
			'<%if (isSearch){%>'+
		    '<tr><th id="thSearchTrail" colspan="2" style="display:cell;text-align:center;"></th><th style="display:cell;">&nbsp</th></tr><%}%>'+
		    '<%if (isSearch){%><div class="btn3lurGlyph" style="font-size:15px;width=100%;text-align:center;padding-left:8px;"><span class="glyphicon glyphicon-remove" style="vertical-align:bottom;"></span></div><%}%>'+
			'<% for (var i=(pNum-1)*pSize,iL=Math.min(pNum*pSize,p.length);i<iL;i++){%>'+
			'<tr class="trBtnLuSelect" value="<%=p[i].label%>"><td colspan="3"><%=p[i].label%></td></tr><%}%>'+
			'<tr><th style="text-align:center;"><div class="btn<%=pNum>1?3:4%>Glyph btnPrev" style="display:inline;"><span class="glyphicon glyphicon-chevron-left"></span></div></th>'+
			'<th style="text-align:center;"><div style="display:inline;"><%=pNum%> of <%=pMax%></div></th>'+
			'<th style="text-align:center;"><div class="btn<%=pNum<pMax?3:4%>Glyph btnNext" style="display:inline;"><span class="glyphicon glyphicon-chevron-right"></span></div></th></tr>';	
	var _cLuUserBuildStr =
			'<tr><th colspan="4" style="border-bottom:none;">Select <%=s%></th></tr>'+
			'<tr><th style="display:table-cell;text-align:center;border-bottom:none;">&nbsp;</th>'+
			'<th style="display:table-cell;text-align:left;border-bottom:none;"><div style="display:inline;padding-right:5px;"><input id="inpFnameSearch" type="text" value="" style="color:black;"/></div></th>'+
			'<th style="display:table-cell;text-align:left;border-bottom:none;"><div style="display:inline;"><input id="inpLnameSearch" type="text" value="" style="color:black;"/></div></th>'+
		    '<th style="display:table-cell;text-align:left;border-bottom:none;"><div style="display:inline;"><div class="btn3luGlyph" style="font-size:12px;width=100%;text-align:center;"><span class="glyphicon glyphicon-search" style="vertical-align:top;padding-left:5px;"></span></div>'+
			'<%if (isSearch){%><div class="btn3lurGlyph" style="font-size:15px;width=100%;text-align:center;"><span class="glyphicon glyphicon-remove" style="vertical-align:middle;;padding-left:5px;"></span></div><%}%></div></th></tr>'+
			'<%if (isSearch){%>'+
		    '<tr><th style="text-align:right;">Search Trail:</th><th id="thFnameSearchTrail" style="display:cell;text-align:center;"></th><th id="thLnameSearchTrail" style="display:cell;text-align:center;"></th><th style="display:cell;">&nbsp</th></tr><%}%>'+
			'<tr><th style="display:table-cell;text-align:center;">Full Name</th>'+
			'<th style="display:table-cell;text-align:left;"><div style="display:inline">First Name</div>'+
	        '<div id="btnSort1" class="btn3SortGlyph<%=iSort==1?" btn3SortGlyphLarge":""%>" style="display:inline;text-align:center;padding-left:30px;"><span class="glyphicon glyphicon-sort-by-alphabet" style="vertical-align:middle;"></span></div>'+
	        '<div id="btnSort2" class="btn3SortGlyph<%=iSort==2?" btn3SortGlyphLarge":""%>" style="display:inline;text-align:center;padding-left:4px;"><span class="glyphicon glyphicon-sort-by-alphabet-alt" style="vertical-align:middle;"></span></div></th>'+
			'<th style="display:table-cell;text-align:left;"><div style="display:inline">Last Name</div>'+
	        '<div id="btnSort3" class="btn3SortGlyph<%=iSort==3?" btn3SortGlyphLarge":""%>" style="display:inline;text-align:center;padding-left:30px;"><span class="glyphicon glyphicon-sort-by-alphabet" style="vertical-align:middle;"></span></div>'+
	        '<div id="btnSort4" class="btn3SortGlyph<%=iSort==4?" btn3SortGlyphLarge":""%>" style="display:inline;text-align:center;padding-left:4px;"><span class="glyphicon glyphicon-sort-by-alphabet-alt" style="vertical-align:middle;"></span></div></th>'+
			'<th>&nbsp;</th></tr>'+
			'<% for (var i=(pNum-1)*pSize,iL=Math.min(pNum*pSize,p.length);i<iL;i++){%>'+
			'<tr class="trBtnLuSelect" value="<%=p[i].value%>">' +
			'<td><%=p[i].label%></td><td><%=p[i].fname%></td><td colspan="2"><%=p[i].lname%></td></tr><%}%>'+
			'<tr><th colspan="4" style="text-align:center;">'+
		    '<div class="btn<%=pNum>1?3:4%>Glyph btnPrev" style="display:inline;padding-right:35px;"><span class="glyphicon glyphicon-chevron-left"></span></div>'+
			'<div style="display:inline;"><%=pNum%> of <%=pMax%></div>'+
			'<div class="btn<%=pNum<pMax?3:4%>Glyph btnNext" style="display:inline;padding-left:35px;"><span class="glyphicon glyphicon-chevron-right"></span></div></th></tr>';
	var _cRdbBuildStr =
			'<tr><th colspan="3">Is <%=s%>?</th></tr>'+
			'<tr class="trRdbRow"><td style="text-align:right;padding-right:10px;"><span class="glyphicon glyphicon-ok" style="padding-right:10px;"></span> Yes:</td>'+
			'<td style="text-align:left;padding:0;"><input type="radio" id="rdbCheck" name="rdbcheckbox" value="1"></td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>'+
			'<tr class="trRdbRow"><td style="text-align:right;padding-right:10px;"><span class="glyphicon glyphicon-ban-circle" style="padding-right:10px;"></span> No:</td>'+
			'<td style="text-align:left;padding:0;"><input type="radio" id="rdbUncheck" name="rdbcheckbox" value="0"></td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>'+
		    '<tr><td colspan="3"><div class="btnRdbContainer"><div id="divBtnRdbUpdate" class="btnRdb" style="display:none;">Update</div><div id="divBtnRdbExit" class="btnRdb">Exit</div></div></td></tr>'
	var _cTeBuildStr =
			'<tr><th>Edit <%=s%></th></tr>'+
			'<tr class="trTeRow"><td style="padding:0;"><input id="inpTe" type="text" style="width:100%;padding-right:1px;" value=""/></td>'+
		    '<tr><td><div class="btnTeContainer"><div id="divBtnTeUpdate" class="btnTe" style="display:none;">Update</div><div id="divBtnTeExit" class="btnTe">Exit</div></div></td></tr>'
	var _sSearchStrTrail=[];
	var _sSearchResultTrail=[];
	var _sLuCurrentTitle;
	var _sLastSearchStr='';
	var _iSort;
	
	var _trList;
	var _trListLen;
	var _trIdx;
	// -------------------------------------------
	// END Private variables   
	// *******************************************
	
    $.fn.myUtilPlugin = function () {		
		/* ******************************************************************************** */
		/* ******************************************************************************** */
		/* BEGIN Private functions   
		/* ******************************************************************************** */
		/* ******************************************************************************** */
		var luSearchName=function(argFname,argLname)
		{
			var isFnameSearch=argFname.length>0;
			var isLnameSearch=argLname.length>0;
			if (!isFnameSearch && !isLnameSearch) return _p;
			argFname=argFname.toLowerCase();
			argLname=argLname.toLowerCase();
			_sSearchStrTrail.push({fname: argFname,lname: argLname});
			_sSearchResultTrail.push(_p);
			var myMatchList = [];
			var isFnameContains=false;
			var isLnameContains=false;
			if (argFname.startsWith('*')) 
			{
				isFnameContains=true;
				 argFname =  argFname.substr(1);
			}
			if (argLname.startsWith('*')) 
			{
				isLnameContains=true;
				 argLname =  argLname.substr(1);
			}
			var mySearchFn;
			switch(true)
			{
				case(isFnameSearch && !isLnameSearch):
					mySearchFn= (
						isFnameContains?
							function(s,sFpat,sLpat){ 
								let Fname=(s==undefined || s.fname==undefined || s.fname==null)?'':s.fname.toLowerCase(); 
								return (Fname.indexOf(sFpat)>=0); } :
							function(s,sFpat,sLpat){ 
								let Fname=(s==undefined || s.fname==undefined || s.fname==null)?'':s.fname.toLowerCase(); 
								return (Fname.startsWith(sFpat)); }
						);
					break;
				case(!isFnameSearch && isLnameSearch):
					mySearchFn= (
						isLnameContains?
							function(s,sFpat,sLpat){ 
								let Lname=(s==undefined || s.lname==undefined || s.fname==null)?'':s.lname.toLowerCase(); 
								return (Lname.indexOf(sLpat)>=0); } :
							function(s,sFpat,sLpat){ 
								let Lname=(s==undefined || s.lname==undefined || s.fname==null)?'':s.lname.toLowerCase(); 
								return (Lname.startsWith(sLpat)); }
						);
					break;
				case(isFnameSearch && isLnameSearch):
					switch(true)
					{
						case(!isFnameContains && !isLnameContains):
							mySearchFn=function(s,sFpat,sLpat){ 
								let Fname=(s==undefined || s.fname==undefined || s.fname==null)?'':s.fname.toLowerCase(); 
								let Lname=(s==undefined || s.lname==undefined || s.lname==null)?'':s.lname.toLowerCase(); 
								return (
									Fname.startsWith(sFpat) &&
									Lname.startsWith(sLpat) 
								); 
							}							
							break;
						case(!isFnameContains && isLnameContains):
							mySearchFn=function(s,sFpat,sLpat){ 
								let Fname=(s==undefined || s.fname==undefined || s.fname==null)?'':s.fname.toLowerCase(); 
								let Lname=(s==undefined || s.lname==undefined || s.lname==null)?'':s.lname.toLowerCase(); 
								return (
									Fname.startsWith(sFpat) &&
									Lname.indexOf(sLpat)>=0 
								); 
							}
							break;
						case(isFnameContains && !isLnameContains):
							mySearchFn=function(s,sFpat,sLpat){ 
								let Fname=(s==undefined || s.fname==undefined || s.fname==null)?'':s.fname.toLowerCase(); 
								let Lname=(s==undefined || s.lname==undefined || s.lname==null)?'':s.lname.toLowerCase(); 
								return (
									Fname.indexOf(sFpat)>=0 &&
									Lname.startsWith(sLpat) 
								); 
							}
							break;
						case(isFnameContains && isLnameContains):
							mySearchFn=function(s,sFpat,sLpat){ 
								let Fname=(s==undefined || s.fname==undefined || s.fname==null)?'':s.fname.toLowerCase(); 
								let Lname=(s==undefined || s.lname==undefined || s.lname==null)?'':s.lname.toLowerCase(); 
								return (
									Fname.indexOf(sFpat)>=0 &&
									Lname.indexOf(sLpat)>=0
								); 
							}
							break;							
					}
					break;
			}
			for(var idxCtr=0,idxLen=_p.length;idxCtr<idxLen;idxCtr++)
			{
				if (mySearchFn(_p[idxCtr],argFname,argLname))
				{
					myMatchList.push(_p[idxCtr]);
				}
			}
			return myMatchList;			
		}
		var luSearch=function(mySearchStr)
		{
			_sSearchStrTrail.push(mySearchStr);				
			_sSearchResultTrail.push(_p);
			var myMatchList = [];
			var isContains=false;
			var isMatchCase=false;
			var isIgnoreWhite=false;
			var mySearchFn;
			//
			if (mySearchStr.startsWith('*')) 
			{
				isContains=true;
				mySearchStr = mySearchStr.substr(1);
			}
			var idx=mySearchStr.lastIndexOf('/');
			if (idx>0)
			{
				var mySubStr = mySearchStr.substr(idx);
				mySearchStr = mySearchString.slice(0,idx-1);
				if (mySubStr.indexOf('m')>0) isMatchCase=true;				
				if (mySubStr.indexOf('z')>0) isIgnoreWhite=true;
			}
			//
			switch(true)
			{
				case (!isContains && !isMatchCase && !isIgnoreWhite ):
					mySearchFn = function(s,sPat){ return s.toLowerCase().startsWith(sPat); }
					break;
				case (!isContains && !isMatchCase &&  isIgnoreWhite ):
					mySearchFn = function(s,sPat){ return s.toLowerCase().replace(/\s/g,'').startsWith(sPat.replace(/\s/g,'')); }
					break;
				case (!isContains &&  isMatchCase && !isIgnoreWhite ):
					mySearchFn = function(s,sPat){ return s.startsWith(sPat); }
					break;
				case (!isContains &&  isMatchCase &&  isIgnoreWhite ):
					mySearchFn = function(s,sPat){ return s.replace(/\s/g,'').startsWith(sPat.replace(/\s/g,'')); }
					break;
				case ( isContains && !isMatchCase && !isIgnoreWhite ):
					mySearchFn = function(s,sPat){ return s.toLowerCase().indexOf(sPat.toLowerCase())>=0; }
					break;
				case ( isContains && !isMatchCase &&  isIgnoreWhite ):
					mySearchFn = function(s,sPat){ return s.toLowerCase().replace(/\s/g,'').indexOf(sPat.toLowerCase().replace(/\s/g,''))>=0; }
					break;
				case ( isContains &&  isMatchCase && !isIgnoreWhite ):
				   mySearchFn = function(s,sPat){ return s.indexOf(sPat)>=0; }
					break;
				case ( isContains &&  isMatchCase &&  isIgnoreWhite ):
				   mySearchFn = function(s,sPat){ return s.replace(/\s/g,'').indexOf(sPat.replace(/\s/g,''))>=0; }
				   break;
			}	
			for(var idxCtr=0,idxLen=_p.length;idxCtr<idxLen;idxCtr++)
			{
				if (mySearchFn(_p[idxCtr].label,mySearchStr))
				{
					myMatchList.push(_p[idxCtr]);
				}
			}
			return myMatchList;
		}
		var strCompare=function(a,b)
		{
		  var myResult=0;
		  switch(true)
		  {
			  case (a<b):
				  myResult=-1;
				  break;
			  case (a>b):
				  myResult=1;
				  break;				  
		  }
		  return myResult;
		}
		var luFnameSort = function(a,b) {
			var fnameA = (a==undefined || a.fname==undefined || a.fname==null)?'':a.fname.toLowerCase(); // ignore upper and lowercase
  			var fnameB = (b==undefined || b.fname==undefined || b.fname==null)?'':b.fname.toLowerCase(); // ignore upper and lowercase
			return strCompare(fnameA,fnameB);
		}		
		var luFnameDesc = function(a,b) {
			var fnameA = (a==undefined || a.fname==undefined || a.fname==null)?'':a.fname.toLowerCase(); // ignore upper and lowercase
  			var fnameB = (b==undefined || b.fname==undefined || b.fname==null)?'':b.fname.toLowerCase(); // ignore upper and lowercase
			return -1*strCompare(fnameA,fnameB);
		}		
		var luLnameSort = function(a,b) {
			var lnameA = (a==undefined || a.lname==undefined || a.lname==null)?'':a.lname.toLowerCase(); // ignore upper and lowercase // ignore upper and lowercase
  			var lnameB = (b==undefined || b.lname==undefined || b.lname==null)?'':b.lname.toLowerCase(); // ignore upper and lowercase
			return strCompare(lnameA,lnameB);
		}		
		var luLnameDesc = function(a,b) {
			var lnameA = (a==undefined || a.lname==undefined || a.lname==null)?'':a.lname.toLowerCase(); // ignore upper and lowercase // ignore upper and lowercase
  			var lnameB = (b==undefined || b.lname==undefined || b.lname==null)?'':b.lname.toLowerCase(); // ignore upper and lowercase
			return -1*strCompare(lnameA,lnameB);
		}
		var elPosition = function(e)
		{
			return $(e).position();
		}
		var elOffset = function(e)
		{
			return $(e).offset();
		}
		var luFieldDiv = function(e)
		{
			if ($(e).attr('class').indexOf('glyph')>=0){
				e=$(e).parent();
			}
			return $(e).parent().children('.divTd');
		}
		var luFieldParent = function(e)
		{
			if ($(e).attr('class').indexOf('glyph')>=0){
				e=$(e).parent();
			}
			return $(e).parent().parent().parent();	
		}
		var luType = function(e)
		{
			var myReturn = 'none';
			var myClist=$(e).attr('class');
			switch(true) {
				case (myClist.indexOf('tdExpand')>=0):
					myReturn='Expand';
					_p = _pDummy;
					break;
				case (myClist.indexOf('tdPortfolio')>=0):
					myReturn='Portfolio';
					_p=$.myLuData.result.portfolio;
					break;
				case (myClist.indexOf('tdProgram')>=0):
					myReturn='Program';
					_p=$.myLuData.result.program;
					break;
				case (myClist.indexOf('tdConfigItem')>=0):
					myReturn='Configuration Item';
					_p=$.myLuData.result.cmdbci;
					break;
				case (myClist.indexOf('tdProjectNum')>=0):
					myReturn='Project';
					_p = _pDummy;
					break;
				case (myClist.indexOf('tdProjectName')>=0):
					myReturn = 'Project Name';
					_p = _pDummy;
					break;
				case (myClist.indexOf('tdTaskName')>=0):
					myReturn='Task Name';
					_p = _pDummy;
					break;					
				case (myClist.indexOf('tdProjectMgr')>=0):
					myReturn='Project Mgr';
					_p=$.myLuData.result.projmgr;
					break;					
				case (myClist.indexOf('tdAssignedTo')>=0):
					myReturn='Assigned To';
					_p=$.myLuData.result.assignedto;
					break;
				case (myClist.indexOf('tdTaskAssignedTo')>=0):
					myReturn='Assigned To';
					_p=$.myLuData.result.pmtassignedto;
					break;					
				case (myClist.indexOf('tdTaskAssignmentGroup')>=0):					
					myReturn='Assignment Grp';
					_p=$.myLuData.result.pmtassignmentgroup;
					break;
				case (myClist.indexOf('tdPhase_')>=0):
					myReturn='Phase';
					_p=$.myLuData.result.phase;
					break;
				case (myClist.indexOf('tdPhaseType')>=0):
					myReturn='Phase Type';
					_p=$.myLuData.result.phasetype;
					break;
				case (myClist.indexOf('tdSchedule')>=0):
					myReturn='Schedule';
					_p=$.myLuData.result.schedule;
					break;
				case (myClist.indexOf('tdState')>=0):
				case (myClist.indexOf('tdTaskState')>=0):					
					myReturn='State';
					_p=$.myLuData.result.state;
					break;
				case (myClist.indexOf('tdPriority')>=0):
				case (myClist.indexOf('tdTaskPriority')>=0):					
					myReturn='Priority';
					_p=$.myLuData.result.priority;
					break;
				case (myClist.indexOf('tdRisk')>=0):
					myReturn='Risk';
					_p=$.myLuData.result.risk;
					break;
				case (myClist.indexOf('tdTaskImpact')>=0):
					myReturn='Impact';
					_p=$.myLuData.result.pmtimpact;
					break;	
				case (myClist.indexOf('tdTaskType')>=0):
					myReturn='Task Type';
					_p=$.myLuData.result.pmttasktype;
					break;					
				case (myClist.indexOf('tdStrategicPriority')>=0):
					myReturn='Strategic Priority';
					_p = _pDummy;
					break;
				case (myClist.indexOf('tdHotItem')>=0):
					myReturn='Hot Item';
					_p = _pDummy;
					break;
				case (myClist.indexOf('tdNeedsFollowUp')>=0):
					myReturn='Needs Follow Up';
					_p = _pDummy;
					break;
				case (myClist.indexOf('tdTaskConstraint')>=0):					
				case (myClist.indexOf('tdConstraint')>=0):
					myReturn='Constraint';
					_p=$.myLuData.result.constraint;
					break;
				case (myClist.indexOf('tdPlannedStartDate ')>=0):
				case (myClist.indexOf('tdTaskPlannedStartDate ')>=0):					
					myReturn='Planned Start Date';
					_p = _pDummy;
					break;
				case (myClist.indexOf('tdPlannedEndDate')>=0):
				case (myClist.indexOf('tdTaskPlannedEndDate')>=0):					
					myReturn='Planned End Date';
					_p = _pDummy;
					break;
				case (myClist.indexOf('tdTaskActualStartDate')>=0):					
				case (myClist.indexOf('tdActualStartDate')>=0):
					myReturn='Actual Start Date';
					_p = _pDummy;
					break;
				case (myClist.indexOf('tdTaskActualEndDate')>=0):					
				case (myClist.indexOf('tdActualEndDate')>=0):
					myReturn='Actual End Date';
					_p = _pDummy;
					break;
				case (myClist.indexOf('tdOriginalStartDate')>=0):
					myReturn='Original Start Date';
					_p = _pDummy;
					break;
				case (myClist.indexOf('tdOriginalEndDate')>=0):
					myReturn='Original End Date';
					_p = _pDummy;
					break;
				case (myClist.indexOf('tdTaskKeyMilestone')>=0):
					myReturn='Task Key Milestone';
					_p = _pDummy;
					break;					
				case (myClist.indexOf('tdTaskMilestone')>=0):
					myReturn='Task Milestone';
					_p = _pDummy;
					break;					
				default:
					break;					
		    }
			return myReturn;			
		}
		var initDatePicker = function(e,dpDate)
		{
			var myOffset = elOffset(e);
			var myHeight = e.outerHeight();
			var x = myOffset.left;
			var y = myOffset.top + myHeight;				
			$('#divDatePickerContainer').css( { left: x + "px", top: y + "px", position:'relative' } ); 
			$('#divDatePickerContainer').show();
			$('#divBtnDpExitContainer').show();
			$('#trFinalCalBtnRow').hide();
			myDtmStr = $('#inpDp').val();
			if (myDtmStr.indexOf('YYYY-MM-DD')>=0)
			{
				$('#divBtnDpEmpty').hide();
			}
			else
			{
				$('#divBtnDpEmpty').show();
			}
			$('#inpTime').change($().myUtilPlugin().calTimeUpd);
			$(function() {$('#divDatePicker').datepicker({
					dateFormat: 'yy-mm-dd',
					defaultDate: dpDate,
					onSelect: $().myUtilPlugin().calSelect,
					onClose: $().myUtilPlugin().calClose
				});
			});			
		}
		var luBuilder = function(luTypeStr)
		{			
			//debugger;
			_sLuCurrentTitle = luTypeStr;
			var myData,myHtmlStr;
			$('#tblLu').children().remove();
			switch(luTypeStr) {
				case 'Portfolio':
				case 'Program':
				case 'Phase':
				case 'Phase Type':
				case 'Schedule':
				case 'State':
				case 'Priority':
				case 'Risk':
				case 'Constraint':
				case 'Impact':
				case 'Task Type':
				case 'Assignment Grp':
					myData = {s: luTypeStr,p: _p};
				    myHtmlStr = ejs.render(_cLuBuildStr,myData);
					$('#tblLu').html(myHtmlStr);
					$('#tblLu').children($.myBtnLuSelectClass).off().click($().myUtilPlugin().luSelect);			
					break;								
				case 'Project Mgr':
				case 'Assigned To':
					var myPmax=Math.ceil(_p.length/20);					
					var myIsSearch = (_sSearchResultTrail.length>0)
					var myPnum=parseInt($('#tblLu').attr('value'));					
					myData = {s: luTypeStr,p: _p, pNum: myPnum, pSize: 20, pMax: myPmax, isSearch: myIsSearch, iSort: _iSort};
				    myHtmlStr = ejs.render(_cLuUserBuildStr,myData);
					$('#tblLu').html(myHtmlStr);
					$('#tblLu').children($.myBtnLuSelectClass).off().click($().myUtilPlugin().luSelect);			
					$('#tblLu').find($.myBtn3GlyphClass).off().click($().myUtilPlugin().luPageUser);
					$('#tblLu').find($.myBtn3SortGlyphClass).off().click($().myUtilPlugin().luSortUser);
					$('#tblLu').find($.myBtn3luGlyphClass).off().click($().myUtilPlugin().luSearchUser);										
					$('#tblLu').find($.myBtn3lurGlyphClass).off().click($().myUtilPlugin().luRevertUser);
					if (myIsSearch)
					{
						var myFs='';
						var myLs='';
						for (var i=0,iLen=_sSearchStrTrail.length;i<iLen;i++)
						{
							myFs+=_sSearchStrTrail[i].fname+';';
							myLs+=_sSearchStrTrail[i].lname+';';
						}						
						$('#thFnameSearchTrail').text(myFs);
						$('#thLnameSearchTrail').text(myLs);						
					}
					break;									
				case 'Configuration Item':
					//debugger;
					var myPmax=Math.ceil(_p.length/20);
					var myIsSearch = (_sSearchResultTrail.length>0);
					var myPnum=parseInt($('#tblLu').attr('value'));					
					myData = {s: luTypeStr,p: _p, pNum: myPnum, pSize: 20, pMax: myPmax, isSearch: myIsSearch};
				    myHtmlStr = ejs.render(_cLuCiBuildStr,myData);
					$('#tblLu').html(myHtmlStr);
					$('#tblLu').children($.myBtnLuSelectClass).click($().myUtilPlugin().luSelect);			
					$('#tblLu').find($.myBtn3GlyphClass).click($().myUtilPlugin().luPageCi);
					$('#tblLu').find($.myBtn3luGlyphClass).click($().myUtilPlugin().luSearchCi);
					$('#tblLu').find($.myBtn3lurGlyphClass).click($().myUtilPlugin().luRevertCi);
					if (myIsSearch)
					{
						var myS='Search Trail: ';
						for (var i=0,iLen=_sSearchStrTrail.length;i<iLen;i++)
						{
							myS+=_sSearchStrTrail[i]+';';
						}						
						$('#thSearchTrail').text(myS);											
					}
					break;
				case 'Hot Item':
				case 'Needs Follow Up':
				case 'Task Key Milestone':
				case 'Task Milestone':
					//debugger;
					myData = {s: luTypeStr,p: _p};
				    myHtmlStr = ejs.render(_cRdbBuildStr,myData);
					$('#tblLu').html(myHtmlStr);
					var myInitVal='';
					myInitVal = _eFieldDiv.attr('value').trim();
					if (!(myInitVal==undefined))
					{
						if (myInitVal.length>0)
						{
							if (myInitVal=='true')
							{
								$('#rdbCheck').attr('checked',true);
							}
							else if (myInitVal=='false')
							{
								$('#rdbUncheck').attr('checked',true);							
							}							
						}
					}
					$('#divBtnRdbExit').click($().myUtilPlugin().luExit);
					$('#tblLu').find('input').click($().myUtilPlugin().rdbChange);
					break;
				case 'Task Name':
				case 'Project Name':
				case 'Strategic Priority':				
					//debugger;
					myData = {s: luTypeStr,p: _p};
				    myHtmlStr = ejs.render(_cTeBuildStr,myData);
					$('#tblLu').html(myHtmlStr);
					var myInitVal='';
					myInitVal = _eFieldDiv.attr('value').trim();
					if (!(myInitVal==undefined))
					{
						if (myInitVal.length>0)
						{

							$('#tblLu').find('input').val(myInitVal);
						}
					}
					$('#divBtnTeExit').click($().myUtilPlugin().luExit);
					$('#tblLu').find('input').change($().myUtilPlugin().teChange);
					$('#tblLu').find('input').bind("paste",$().myUtilPlugin().teChange);
					$('#tblLu').find('input').bind("input",$().myUtilPlugin().teChange);
					break;					
				//default
			}
		}
		var initLu = function(e)
		{
			var myOffset = elOffset(e);
			var myHeight = e.outerHeight();
			var x = myOffset.left;
			var y = myOffset.top + myHeight;
			_sSearchStrTrail=[];
			_sSearchResultTrail=[];	
			_sLastSearchStr = '';			
			$('#tblLu').attr('value','1');
			luBuilder(luType(e));
			$('#divLuContainer').css( { left: x + 'px', top: y + 'px', position:'relative' } );
			$('#divLuContainer').show(); 
		}
		var statusLu = function(e,newStatus)
		{
			var currStatus = e.attr('status');
			if (newStatus == undefined)
			{
				switch (currStatus)
				{
					case 'new':
					case 'snow':
						e.attr('status','update');
						e.css('background-color','#faebd7');
						break;
					case 'empty':
						e.attr('status','new');
						e.css('background-color','#faebd7');
						break;
					default:
						e.attr('status','update');				
						e.css('background-color','#faebd7');
				}
			}
			else
			{
				switch(newStatus)
				{
					case 'new':
					case 'update':
						e.attr(status,newStatus);
						if (newStatus != currStatus)
							e.css('background-color','#faebd7');
						else 
							e.css('background-color','#ffffff');
						break;
					case 'empty':
						e.attr(status,newStatus);
						if (newStatus != currStatus)
							e.css('background-color','#faebd7');
						else 
							e.css('background-color','#ffffff');
						break;
					default:
						e.attr(status,newStatus);
						if (newStatus != currStatus)
							e.css('background-color','#faebd7');
						else 
							e.css('background-color','#ffffff');
						break;					
				}
			}
		}
		var endLu = function()
		{
			_sSearchStrTrail=[];
			_sSearchResultTrail=[];	
			_sLastSearchStr = '';							
			$('#divLuContainer').hide(); 				
			$('#tblLu').children().remove();			
		}
		var endCal = function()
		{
			$('#divDatePicker').datepicker('destroy');
			$('#trFinalCalBtnRow').hide();
			$('#inpTime').off('change');
			$('#divBtnDpTimeUpd').hide();				
			$('#divDatePickerContainer').hide();			
		}
		var ecFirst = function(e,isExpand)
		{
			var myGlyph = e.find('.divBtnExpCol').first().children('span').first();
			var myClist = myGlyph.attr('class');
			var thDiv = e.find('div.divThead').first();			
			if (isExpand)
			{
				e.show();
				thDiv.show();
				if (!(myClist == undefined))
				{
					if (myClist.indexOf('glyphicon-plus')<0)
					{
						myGlyph.removeClass('glyphicon-minus');
						myGlyph.addClass('glyphicon-plus');
					}													
				}								
			} 
			else
			{
				thDiv.hide();
				e.hide();
			}
		}
		var ecNext = function(e,isExpand)
		{
			var myGlyph = e.find('.divBtnExpCol').first().children('span').first();
			var myClist = myGlyph.attr('class');
			var thDiv = e.find('div.divThead').first();
			if (isExpand)
			{
				e.show();
				thDiv.hide();
				if (!(myClist == undefined))
				{
					if (myClist.indexOf('glyphicon-plus')<0)
					{
						myGlyph.removeClass('glyphicon-minus');
						myGlyph.addClass('glyphicon-plus');
					}													
				}
			} 
			else
			{
				thDiv.hide();
				e.hide();
			}
		}
		var uBuildData=function()
		{
			var myCurrentList=[];
			myCurrentList.push(uGatherData($(_trList[_trIdx])));
			_trIdx++;
			while (_trIdx < _trListLen)
			{
				let myCurrentLevel= myCurrentList.last().level;
				let myNext = _trList[_trIdx];
				let myNextLevel = $(myNext).attr('level');
				if (myNextLevel > myCurrentLevel)
				{
					myCurrentList.updLastProp(uBuildData(),'childlist');
					continue;
				}
				else if (myNextLevel == myCurrentLevel)
				{
					myCurrentList.push(uGatherData($(myNext)));
					_trIdx++;
				}
				else if (myNextLevel < myCurrentLevel)
				{
					break;
				}
			}
			return myCurrentList;
		}
		var uGatherData=function(e)
		{
			var lvl = e.attr('level')
			if (lvl>"0")
				return uGatherTaskData(e);				
			else
				return uGatherProjData(e);
		}

		var uBuildLvDataNode=function(e)
		{
			var d=e.find('.divTd').first();
			var myNode= { value: d.attr('value'), label: d.text(), datastatus: e.attr('status') } 
			return myNode;
		}
		var uGatherProjData=function(e)
		{
			var proj={};	
			proj.level = e.attr('level');
			proj.portfolio=uBuildLvDataNode(e.find('.divTd.tdPortfolio').first());
			proj.program=uBuildLvDataNode(e.find('.divTd.tdProgram').first());
			proj.configitem=uBuildLvDataNode(e.find('.divTd.tdConfigItem').first());
			proj.projectnum=uBuildLvDataNode(e.find('.divTd.tdProjectNum').first());
			proj.projectname=uBuildLvDataNode(e.find('.divTd.tdProjectName').first());
			proj.projectmgr=uBuildLvDataNode(e.find('.divTd.tdProjectMgr').first());
			proj.assignedto=uBuildLvDataNode(e.find('.divTd.tdAssignedTo').first());
			proj.phase_=uBuildLvDataNode(e.find('.divTd.tdPhase_').first());
			proj.phasetype=uBuildLvDataNode(e.find('.divTd.tdPhaseType').first());
			proj.schedule=uBuildLvDataNode(e.find('.divTd.tdSchedule').first());
			proj.state=uBuildLvDataNode(e.find('.divTd.tdState').first());
			proj.priority=uBuildLvDataNode(e.find('.divTd.tdPriority').first());
			proj.risk=uBuildLvDataNode(e.find('.divTd.tdRisk').first());
			proj.strategicpriority=uBuildLvDataNode(e.find('.divTd.tdStrategicPriority').first());
			proj.hotitem=uBuildLvDataNode(e.find('.divTd.tdHotItem').first());
			proj.needsfollowup=uBuildLvDataNode(e.find('.divTd.tdNeedsFollowUp').first());
			proj.plannedstartdate=uBuildLvDataNode(e.find('.divTd.tdPlannedStartDate').first());
			proj.plannedenddate=uBuildLvDataNode(e.find('.divTd.tdPlannedEndDate').first());
			proj.actualstartdate=uBuildLvDataNode(e.find('.divTd.tdActualStartDate').first());
			proj.actualenddate=uBuildLvDataNode(e.find('.divTd.tdActualEndDate').first());
			proj.childlist=[];
			return proj;
		}

		var uGatherTaskData=function(e)
		{
			var task={};
			task.level = e.attr('level');
			task.tasknum=uBuildLvDataNode(e.find('.divTd.tdTaskNum').first());			
			task.taskname=uBuildLvDataNode(e.find('.divTd.tdTaskName').first());
			task.taskassignmentgroup=uBuildLvDataNode(e.find('.divTd.tdTaskAssignmentGroup').first());
			task.taskassignedto=uBuildLvDataNode(e.find('.divTd.tdTaskAssignedTo').first());
			task.taskstate=uBuildLvDataNode(e.find('.divTd.tdTaskState').first());
			task.taskpriority=uBuildLvDataNode(e.find('.divTd.tdTaskPriority').first());
			task.taskimpact=uBuildLvDataNode(e.find('.divTd.tdTaskImpact').first());
			task.tasktype=uBuildLvDataNode(e.find('.divTd.tdTaskType').first());
			task.taskconstraint=uBuildLvDataNode(e.find('.divTd.tdTaskConstraint').first());
			task.taskkeymilestone=uBuildLvDataNode(e.find('.divTd.tdTaskKeyMilestone').first());
			task.taskmilestone=uBuildLvDataNode(e.find('.divTd.tdTaskMilestone').first());
			task.taskplannedstartdate=uBuildLvDataNode(e.find('.divTd.tdTaskPlannedStartDate').first());
			task.taskplannedenddate=uBuildLvDataNode(e.find('.divTd.tdTaskPlannedEndDate').first());
			task.taskactualstartdate=uBuildLvDataNode(e.find('.divTd.tdTaskActualStartDate').first());
			task.taskactualenddate=uBuildLvDataNode(e.find('.divTd.tdTaskActualEndDate').first());
			task.childlist=[];
			return task;	
		}
		

		/* ******************************************************************************** */
		/* ******************************************************************************** */
		/* END Private functions   
		/* ******************************************************************************** */
		/* ******************************************************************************** */

		/* ******************************************************************************** */
		/* ******************************************************************************** */
		/* BEGIN Public functions   
		/* ******************************************************************************** */
		/* ******************************************************************************** */		
		return {
			luClick: function(event) {
				//debugger;	
				if($($.myDivDatePickerContainerId).is(':visible'))
				{
					endCal();
				}
				$('#divLuContainer').hide(); 				
				_eFieldDiv = luFieldDiv($(event.currentTarget)); 
				_eFieldParent = luFieldParent($(event.currentTarget));
				_iSort = 1;
				initLu(_eFieldParent);
				return false;
			},
			luSelect: function(event) {
				//debugger;
				var myTd = $(event.currentTarget).children('td').first();
				var myLabelStr = myTd.text().trim();
				var myValueStr = myTd.attr('value');
				_eFieldDiv.text(myLabelStr);
				_eFieldDiv.attr('value',myValueStr);
				statusLu(_eFieldParent);
				endLu();
				return false;
			},
			luPageCi: function(event){
				//debugger;
				var myClist=$(event.currentTarget).attr('class');
				var myPnum=parseInt($('#tblLu').attr('value'));
				var myNewPnum=myPnum;
				var myPmax=Math.ceil(_p.length/20);
				if (myClist.indexOf('btnPrev')>0 && myPnum>1)
				{
					myNewPnum--;
				}
				else if (myClist.indexOf('btnNext')>0 && myPnum<myPmax)
				{
					myNewPnum++;
				}
				if (myNewPnum != myPnum)
				{
					$('#tblLu').attr('value',myNewPnum.toString());
					luBuilder(_sLuCurrentTitle);
				}					
				return false;
			},
			luSearchCi: function(event) {
				//debugger;
				var mySearchStr = $(event.currentTarget).parent().parent().find('input').val().trim();
				if (mySearchStr.length>0)
				{
					$('#tblLu').attr('value','1');										
					_p = luSearch(mySearchStr);
					luBuilder(_sLuCurrentTitle);
				}
				return false;				
			},
			luRevertCi: function(event){
				if (_sSearchResultTrail.length>0)
				{
					_p = _sSearchResultTrail.pop();
					if (_sSearchStrTrail.length>0) {
						_sSearchStrTrail.pop();
					}
					luBuilder(_sLuCurrentTitle);					
				}
				return false;
			},
			luPageUser: function(event) {
				//debugger;
				var myClist=$(event.currentTarget).attr('class');
				var myPnum=parseInt($('#tblLu').attr('value'));
				var myNewPnum=myPnum;
				var myPmax=Math.ceil(_p.length/20);
				if (myClist.indexOf('btnPrev')>0 && myPnum>1)
				{
					myNewPnum--;
				}
				else if (myClist.indexOf('btnNext')>0 && myPnum<myPmax)
				{
					myNewPnum++;
				}
				if (myNewPnum != myPnum)
				{
					$('#tblLu').attr('value',myNewPnum.toString());					
					luBuilder(_sLuCurrentTitle);
				}			
				return false;
			},	
			luSortUser: function(event) {
				//debugger;
				var mySort;
				var mySortId = $(event.currentTarget).attr('id');
				switch(mySortId)
				{
					case('btnSort1'):
						_iSort=1;
						mySort=luFnameSort;
						break;
					case('btnSort2'):
						_iSort=2;
						mySort=luFnameDesc;
						break;
					case('btnSort3'):
						_iSort=3;
						mySort=luLnameSort;
						break;
					case('btnSort4'):
						_iSort=4;
						mySort=luLnameDesc;
						break;
				}
				var myNone = _p.shift();				
				_p = _p.sort(mySort);
				_p.unshift(myNone);
				luBuilder(_sLuCurrentTitle);				
				return false;
			},
			luSearchUser: function(event){
				//debugger;
				var myFnameSearch = $('#inpFnameSearch').val().trim();
				var myLnameSearch = $('#inpLnameSearch').val().trim();
				if (myFnameSearch.length>0 || myLnameSearch.length>0)
				{
					_p = luSearchName(myFnameSearch,myLnameSearch);
					$('#tblLu').attr('value','1');					
					luBuilder(_sLuCurrentTitle);
				}				
				return false;
			},
			luRevertUser: function(event){
				if (_sSearchResultTrail.length>0)
				{
					_p = _sSearchResultTrail.pop();
					if (_sSearchStrTrail.length>0) {
						_sSearchStrTrail.pop();
					}
					luBuilder(_sLuCurrentTitle);					
				}				
				return false;
			},
			luExit: function(event){
				endLu();	
				return false;
			},
			calClick: function(event) {
				//debugger;
				if ($($.myDivLuContainerId).is(':visible'))
				{
					endLu();
				}	
				_eFieldDiv = luFieldDiv($(event.currentTarget)); 
				_eFieldParent = luFieldParent($(event.currentTarget));
				//
				var myCurrentDtmStr = _eFieldDiv.attr('value').trim();
				var myDpDate = new Date();
				if (myCurrentDtmStr.indexOf('YYYY-MM-DD')>=0)
				{
					$('#inpDp').val('YYYY-MM-DD');
					var myClassList = _eFieldParent.attr('class');
					if (myClassList.endsWith('EndDate'))
					{
						$('#inpTime').val('17:00');
					} else {						
						$('#inpTime').val('08:00');
					}					
				} 
				else
				{
					var myCurrentDtmList = myCurrentDtmStr.split(' ');
					$('#inpDp').val(myCurrentDtmList[0]);
					myDpDate = new Date(myCurrentDtmList[0]+'T00:00');
					$('#inpTime').val(myCurrentDtmList[1]);
				}
				//
				$('#divBtnDpTimeUpd').hide();
				initDatePicker(_eFieldParent,myDpDate);				
				return false;
			},
			calSelect: function(dtmStr,dpObj){
				//debugger;
				if ($($.myDivLuContainerId).is(':visible'))
				{
					endLu();
				}				
				$('#inpDp').val(dtmStr);
				$('#trFinalCalBtnRow').show();
				$('#inpTime').off('change');
				$('#divBtnDpTimeUpd').hide();
				$('#divBtnDpExitContainer').hide();
				$('#divDatePicker').datepicker('destroy');
				return false;
			},	
			calSelectTimeUpd: function(event){
				//debugger;
				$('#trFinalCalBtnRow').show();
				$('#inpTime').off('change');
				$('#divBtnDpTimeUpd').hide();
				$('#divBtnDpExitContainer').hide();
				$('#divDatePicker').datepicker('destroy');
				return false;
			},			
			calClose: function(dtmStr,dpObj){
				//debugger;
				endCal();
				return false;
			},			
			calAccept: function(event) {
				//debugger;
				var myDate = $('#inpDp').val();
				var myTime = $('#inpTime').val();
				var myDtm = myDate +' '+myTime;
				_eFieldDiv.text(myDtm);
				_eFieldDiv.attr('value',myDtm);
				statusLu(_eFieldParent);
				endCal();
				return false;
			},
			calReject: function() {
				//debugger;
				var myCurrentDtmStr = $('#inpDp').val()+'T00:00';
				var myDpDate = new Date(myCurrentDtmStr);
				initDatePicker(_eFieldParent,myDpDate);
				return false;
			},			
			calTimeUpd: function(event) {
				//debugger;
				myDtmStr = $('#inpDp').val()
				if (myDtmStr.indexOf('YYYY-MM-DD')<0) {
					$('#divBtnDpTimeUpd').show();
					$('#inpTime').off('change');					
				}
				return false;
			},
			calBlank: function(event) {
				//debugger;
				myDtmStr = 'YYYY-MM-DD HH:MM';
				_eFieldDiv.text(myDtmStr);
				_eFieldDiv.attr('value',myDtmStr);
				statusLu(_eFieldParent,'empty');				
				endCal();
				return false;
			},
			uTreeDepth: function(myTreeObj)
			{
				if (myTreeObj == undefined) return 0;
				var currDepth=0;
				var newDepth=0;
				for (var i=0,iLen=myTreeObj.length;i<iLen;i++)
				{
					if (myTreeObj[i].childtasks.length>0)
					{
						newDepth=$().myUtilPlugin().uTreeDepth(myTreeObj[i].childtasks);
						currDepth=Math.max(newDepth,currDepth);						
					}
				}
				return (1+currDepth);
			},
			ecInitTr: function() {
				//debugger;
				$('.divBtnExpCol').off().click($().myUtilPlugin().ecClick);
				var trNodes = $('tr[level]').filter(function(){
												return $(this).attr('level')>'0';
											 });
				trNodes.hide();
				trNodes.find('div.divThead').hide();
			},
			ecClick: function(event) {
				//debugger;
				if ($($.myDivLuContainerId).is(':visible'))
				{
					endLu();
				}
				if($($.myDivDatePickerContainerId).is(':visible'))
				{
					endCal();
				}				
				var myGlyph = $(event.currentTarget).children('span').first();
				var myClist = myGlyph.attr('class');
				var isExpand=false;
				if (myClist.indexOf('glyphicon-plus')>=0)
				{
					isExpand=true;
					myGlyph.removeClass('glyphicon-plus');
					myGlyph.addClass('glyphicon-minus');
				}
				else
				{
					myGlyph.removeClass('glyphicon-minus');
					myGlyph.addClass('glyphicon-plus');					
				}
				//
				var myTr = $(event.currentTarget).parent();
				var myLevel = parseInt(myTr.attr('level'));
				var myNextLevel = myLevel+1;
				var myLevelStr = myLevel.toString();
				var myNextLevelStr = myNextLevel.toString();
				
				var myTrNodeList=myTr.nextAll('tr');
				var myIsFirst=true;
				for (var i=0,iLen=myTrNodeList.length;i<iLen;i++)
				{
					if ($(myTrNodeList[i]).attr('level')==myLevelStr)
					{
						let myTh = $(myTrNodeList[i]).find('div.divThead').first(); 
						if (isExpand)
						{
							if (!myIsFirst) {
								myTh.show();								
							}
							else
							{
								myTh.hide();
							}
						}
						else
						{
							myTh.hide();
						}
						break;
					}
					else if ($(myTrNodeList[i]).attr('level')<myNextLevelStr)
					{
						let myTh = $(myTrNodeList[i]).find('div.divThead').first(); 
						if (isExpand)
						{
							if (!myIsFirst) {
								myTh.show();								
							}
							else
							{
								myTh.hide();
							}
						}
						else
						{
							myTh.hide();
						}
						break;					
					}				
					else if ($(myTrNodeList[i]).attr('level')==myNextLevelStr)
					{
						if (myIsFirst)
						{
							myIsFirst=false;
							ecFirst($(myTrNodeList[i]),isExpand);
						}
						else
						{
							ecNext($(myTrNodeList[i]),isExpand);
						}
					}
					else
					{
						let myTh = $(myTrNodeList[i]).find('div.divThead').first(); 
						myTh.hide();
						$(myTrNodeList[i]).hide();
					}					
				}
				return false;
			},
			rdbChange: function(event)
			{
				//debugger;
				$('#divBtnRdbUpdate').show();
				$('#divBtnRdbUpdate').off().click($().myUtilPlugin().rdbUpdate);
				return false;
			},
			rdbUpdate: function(event)
			{
				//debugger;
				var myRdbVal = $('#tblLu').find('input:checked').val();
				var checkGlyph='<span class="glyphicon glyphicon-ok"></span>';
				var uncheckGlyph='<span class="glyphicon glyphicon-ban-circle"></span>';
				var myLabelStr;
				var myValueStr;
				if (myRdbVal=='1')
				{
					myLabelStr=checkGlyph;
					myValueStr='true';
				}
				else
				{
					myLabelStr=uncheckGlyph;
					myValueStr='false';
				}
				_eFieldDiv.html(myLabelStr);
				_eFieldDiv.attr('value',myValueStr);
				statusLu(_eFieldParent);
				endLu();
				return false;
			},
			teChange: function(event)
			{
				$('#divBtnTeUpdate').show();
				$('#divBtnTeUpdate').off().click($().myUtilPlugin().teUpdate);
				return false;
			},
			teUpdate: function(event)
			{
				debugger;
				var myValueStr = $('#tblLu').find('input').val();
				if (myValueStr == undefined || myValueStr.length<1)
				{
					myValueStr='';
					_eFieldDiv.html('&nbsp;');
				}
				else
				{
					_eFieldDiv.text(myValueStr);					
				}
				_eFieldDiv.attr('value',myValueStr);
				statusLu(_eFieldParent);
				endLu();
				return false;
			},
			ehIgnore: function(event)
			{
				//debugger;
				return false;
			},
			ehWindow: function(event)
			{
				//debugger;
				if ($($.myDivLuContainerId).is(':visible'))
				{
					endLu();
				}
				if($($.myDivDatePickerContainerId).is(':visible'))
				{
					endCal();
				}
			},
			uGather()
			{
				_trList = $('tr[level]');
				_trListLen = _trList.length;
				_trIdx = 0;
				var jData = uBuildData();
				var jDataStr = JSON.stringify(jData);
				//debugger;
				return jDataStr;
			}
		}		
		/* ******************************************************************************** */
		/* ******************************************************************************** */
		/* END Public functions   
		/* ******************************************************************************** */
		/* ******************************************************************************** */
    }
})(jQuery, window, document);